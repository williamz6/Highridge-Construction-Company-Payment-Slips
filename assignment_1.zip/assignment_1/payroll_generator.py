import random

# number of workers
num_workers = 400

# for loop for variables: name, gender, salary
workers = []
for i in range(1, num_workers + 1):
    try:
        name = f"Worker{i}"
        gender = random.choice(["Male", "Female"])
        salary = random.randint(
            5000, 32000
        )  # rand.int() as we are dealing with integers

        # assign values to the workers list
        workers.append({"name": name, "salary": salary, "gender": gender})
    except Exception as e:
        print(f"Error creating worker{i}: {e}")
# print(f"{workers}")
for worker in workers:
    try:
        name = worker["name"]
        salary = worker["salary"]
        gender = worker["gender"]
        level = "unassigned"

        # apply condition
        if 10000 < salary < 20000:
            level = "A1"
        elif 7500 < salary < 30000 and gender == "Female":
            level = "A5-F"
        # print payment slip
        print(f"Payment Slip\n-------------")
        print(f"Name: {name}")
        print(f"Gender: {gender.capitalize()}")
        print(f"Salary: ${salary}")
        print(f"Employee Level: {level}\n")
    except KeyError as e:
        print(f"Missing data for worker {worker.get('name', 'Unknown')}: {e}")
    except Exception as e:
        print(f"Error generating slip for {worker.get('name', 'Unknown')}: {e}")
