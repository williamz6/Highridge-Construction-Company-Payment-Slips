num_workers <- 400

workers <- list()
# for loop for variables: name, gender, salary
for (i in seq(1, num_workers)){
    tryCatch({
        name <- paste0("worker_", i)
        gender <- sample(c("Male", "Female"), 1)
        salary <- sample(5000: 32000, 1)

        # assign values to the list
        workers[[i]] <- list(
            name = name,
            salary = salary,
            gender = gender
        )
    },

    error = function(e) {
        message(paste0("Error creating worker", i, ":", e$message))
    }
    )
}
for (worker in workers){
    tryCatch({
        name <- worker$name
        salary <- worker$salary
        gender <- worker$gender
        level <- "Unknown"

        if (salary> 10000 && salary < 20000){
            level <- "A1"
        }
        else if (salary > 7500 && salary < 30000 && gender == "Female"){
            level <- "A5-F"
        }

        # print workers payment slip
        cat("Paymemnt Slip\n")
        cat(paste("Name:", name, "\n"))
        cat(paste("Gender:", gender, "\n"))
        cat(paste("Salary: $", salary, "\n"))
        cat(paste("Employee Level:", level, "\n\n"))
    },
    error = function(e) {
    cat(paste("Error generating slip for", name, ":", e$message, "\n"))
  })
}


